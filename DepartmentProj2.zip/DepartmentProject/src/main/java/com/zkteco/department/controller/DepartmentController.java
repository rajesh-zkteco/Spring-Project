package com.zkteco.department.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.department.dto.ResultDto;
import com.zkteco.department.entity.Department;
import com.zkteco.department.service.DepartmentService;


@RestController
@RequestMapping("/api/v1/department")
public class DepartmentController {
	Department department;
	@Autowired
	public DepartmentService departmentService;

	
	//fetch all
	@GetMapping()
	public ResultDto getAll(){
		 return departmentService.findDept();
	}
	
	//create department
	@PostMapping()
	public ResultDto saveDepartment(@RequestBody Department department) {
		return departmentService.saveDepartment(department);
		}
	

	//get department by id
	@GetMapping("/{id}")
	public ResultDto findDeptById(@PathVariable("id")String deptid) {
		return departmentService.findDeptById(deptid);	 
	}
	//delete by id
	@DeleteMapping("/{id}")
	public String departmentDeleteById(@PathVariable("id")String deptid) {
		 departmentService.departmentDeleteById(deptid);
		return "delete successfully";
	}
	//update department by id
	@PutMapping("/{id}")
	public ResultDto updateDepartment(@PathVariable("id") String deptid,@RequestBody Department department) {
		return departmentService.updateDepartment(deptid,department);
	}
//	@GetMapping("/all/name/{departmentName}")
//	public ResultDto fetchByName(@PathVariable("departmentName")String departmentName) {
//
//		Department department=departmentService.fetchByName(departmentName);
//		ResultDto result=new ResultDto();
//		result.setCode("1014");
//		result.setMessage("successfully fetch by name record");
//		result.setData(department);
//		return result;
//	}
}
