package com.zkteco.department.converter;

import java.util.List;
import java.util.stream.Collectors;

import com.zkteco.department.dto.ResultDto;
import com.zkteco.department.entity.Department;

public class DepartmentConverter {

//	public ResultDto entityToDto(Department department) {
//		ResultDto dto=new ResultDto();
//		dto.setCode(department.getDepartmentCode());
//		dto.setDAddress(department.getDepartmentAddress());
//		dto.setDMembers(department.getDepartmentMembers());
//		dto.setDName(department.getDepartmentName());
//		dto.setDType(department.getDepartmentType());
//	
//	
//		return dto;
//	}
//	public Department dtoToEntity(ResultDto result) {
//		Department dept=new Department();
//		dept.setDepartmentAddress(result.getDAddress());
//		dept.setDepartmentMembers(result.getDMembers());
//		dept.setDepartmentCode(result.getDCode());
//		dept.setDepartmentType(result.getDType());
//		dept.setDepartmentName(result.getDName());
//		
//		return dept;
//	}
//	public List<ResultDto> entityToDto(List<Department> department){
//		return department.stream().map(x->entityToDto(x)).collect(Collectors.toList());
//	}
}
