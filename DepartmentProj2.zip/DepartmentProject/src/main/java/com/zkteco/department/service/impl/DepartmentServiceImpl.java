package com.zkteco.department.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zkteco.department.dto.ResultDto;
import com.zkteco.department.entity.Department;
import com.zkteco.department.repository.DepartmentRepository;
import com.zkteco.department.service.DepartmentService;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	ResultDto result;
	@Autowired
	DepartmentRepository departmentRepository;


	//find all
	@Override
	public ResultDto findDept() {

		return (ResultDto) departmentRepository.findAll();
	}

	//Save the department
	@Override
	public ResultDto saveDepartment(Department department) {
		departmentRepository.save(department);
		ResultDto result=new ResultDto();
		result.setCode("1011");
		result.setMessage("successfull");
		result.setData(department);
		return result; 

	}
	//
	//find department by id
	@Override
	public ResultDto findDeptById(String deptid)  {

		Optional<Department> dept = departmentRepository.findById(deptid);
		ResultDto result=new ResultDto();
		result.setCode("MO07");
		result.setMessage("Order Created Successfully");
		result.setData(dept);
		// result.add(result);
		return result;

	}

	//Delete department by id
	@Override
	public void departmentDeleteById(String deptid) {
		departmentRepository.deleteById(deptid);
	}
	//update department by id
	@Override
	public ResultDto updateDepartment(String deptid, Department department) {
		Department depDb=departmentRepository.findById(deptid).get();
		if(Objects.nonNull(department.getDepartmentName())&& 
				!"".equalsIgnoreCase(department.getDepartmentName())) {
			depDb.setDepartmentName(department.getDepartmentName());
		}

		if(Objects.nonNull(department.getDepartmentCode())&& 
				!"".equalsIgnoreCase(department.getDepartmentCode())) {
			depDb.setDepartmentCode(department.getDepartmentCode());
		}
		if(Objects.nonNull(department.getDepartmentAddress())&& 
				!"".equalsIgnoreCase(department.getDepartmentAddress())) {
			depDb.setDepartmentAddress(department.getDepartmentAddress());
		}
		departmentRepository.save(depDb);
		ResultDto result =new ResultDto ();
		result.setCode("MO07");
		result.setMessage("Document udated Successfully");
		result.setData(depDb);
		return result;
	}

	//fetch department by name
	@Override
	public Department fetchByName(String departmentName) {

		return departmentRepository.findByDepartmentName(departmentName);
	}

}
