package com.zkteco.department.service;

import java.util.List;

import com.zkteco.department.dto.ResultDto;
import com.zkteco.department.entity.Department;

public interface DepartmentService {
	
   //save department entity
	public ResultDto saveDepartment(Department department);
	//fetch all department entity
	 public ResultDto findDept();
	 
	 public ResultDto findDeptById(String deptid);
	 public void departmentDeleteById(String deptid);
	 public ResultDto updateDepartment(String deptid, Department department);
	public Department fetchByName(String departmentName);
	 
}
